<?php
$datamenu=unserialize($sidemenu);
print_r($datamenu);
echo "</br></br></br>";
print_r($userdata);